# 🚀 دليل النشر السريع - نظام عداد الزوار

## ⏱️ النشر في 3 دقائق فقط!

### الخطوة 1: إنشاء المستودع
1. اذهب إلى [GitHub](https://github.com)
2. انقر على ➕ → New repository
3. اسم المستودع: `expert-engine`
4. اختر Public
5. انقر Create repository

### الخطوة 2: رفع الملفات
1. في المستودع الجديد، انقر على `Add file` → `Upload files`
2. اسحب وأفلت جميع الملفات من ZIP
3. انقر `Commit changes`

### الخطوة 3: تفعيل GitHub Pages
1. اذهب إلى `Settings` → `Pages`
2. `Branch`: اختر `main`
3. `Folder`: اختر `/ (root)`
4. انقر `Save`

### ✅ تم! الموقع جاهز على:
https://2gmil991-cloud.github.io/expert-engine/
